import { InputRow, ShiftType, Constraint } from './types';

export const STORAGE_KEY_ALLOW_CROSS_DAY_SWAP = 'smart_scheduler_allow_cross_day_swap';

export const DAYS = ['Thứ 2', 'Thứ 3', 'Thứ 4', 'Thứ 5', 'Thứ 6'];
export const PERIODS = [
  'Sáng 1', 'Sáng 2', 'Sáng 3', 'Sáng 4', 'Sáng 5',
  'Chiều 1', 'Chiều 2', 'Chiều 3'
];

export const SHIFT_OPTIONS = [
  { id: 'ALL' as ShiftType, label: 'Cả ngày (Sáng & Chiều)', shortLabel: 'Cả ngày', icon: '☀️', description: 'Tất cả 8 tiết học trong ngày' },
  { id: 'MORNING' as ShiftType, label: 'Buổi Sáng (Tiết 1 - 5)', shortLabel: 'Buổi Sáng', icon: '🌅', description: 'Các tiết học buổi sáng (Tiết 1 - 5)' },
  { id: 'AFTERNOON' as ShiftType, label: 'Buổi Chiều (Tiết 1 - 3)', shortLabel: 'Buổi Chiều', icon: '🌇', description: 'Các tiết học buổi chiều (Tiết 1 - 3)' },
];

export const isPeriodInShift = (periodIdx: number, shift: ShiftType): boolean => {
  if (shift === 'ALL') return true;
  if (shift === 'MORNING') return periodIdx < 5;
  if (shift === 'AFTERNOON') return periodIdx >= 5;
  return true;
};

/**
 * Trích xuất cấu hình ca học đang hiệu lực từ danh sách ràng buộc hoặc LocalStorage
 */
export const getActiveShiftConstraints = (customConstraints?: Constraint[]): {
  morningDays: number[];
  afternoonDays: number[];
  morningPeriodCap: number;
  afternoonPeriodCap: number;
} | null => {
  let list: Constraint[] = customConstraints || [];
  if (!list || list.length === 0) {
    if (typeof localStorage !== 'undefined') {
      try {
        const saved = localStorage.getItem('scheduler_constraints');
        if (saved) list = JSON.parse(saved);
      } catch (e) {
        // ignore
      }
    }
  }

  if (!list || list.length === 0) return null;

  // 1. Tìm ràng buộc ca học toàn trường (SCHOOL_SHIFT hoặc CLASS_SHIFT cho ALL / TOAN_TRUONG)
  const schoolWide = list.find(c => 
    c.type === 'SCHOOL_SHIFT' || 
    (c.type === 'CLASS_SHIFT' && (!c.className || c.className === 'ALL' || c.className === 'TOAN_TRUONG'))
  );

  if (schoolWide && (schoolWide.morningDays || schoolWide.afternoonDays)) {
    return {
      morningDays: schoolWide.morningDays || [0, 1, 2, 3, 4],
      afternoonDays: schoolWide.afternoonDays || [],
      morningPeriodCap: schoolWide.morningPeriodCap ?? 5,
      afternoonPeriodCap: schoolWide.afternoonPeriodCap ?? 3
    };
  }

  // 2. Nếu không có cấu hình toàn trường, tổng hợp tập hợp hợp (union) từ tất cả CLASS_SHIFT
  const classShifts = list.filter(c => c.type === 'CLASS_SHIFT');
  if (classShifts.length > 0) {
    const morningDaysSet = new Set<number>();
    const afternoonDaysSet = new Set<number>();
    let maxMorningCap = 5;
    let maxAfternoonCap = 3;

    classShifts.forEach(cs => {
      cs.morningDays?.forEach(d => morningDaysSet.add(d));
      cs.afternoonDays?.forEach(d => afternoonDaysSet.add(d));
      if (cs.morningPeriodCap && cs.morningPeriodCap > maxMorningCap) maxMorningCap = cs.morningPeriodCap;
      if (cs.afternoonPeriodCap && cs.afternoonPeriodCap > maxAfternoonCap) maxAfternoonCap = cs.afternoonPeriodCap;
    });

    return {
      morningDays: Array.from(morningDaysSet),
      afternoonDays: Array.from(afternoonDaysSet),
      morningPeriodCap: maxMorningCap,
      afternoonPeriodCap: maxAfternoonCap
    };
  }

  return null;
};

/**
 * Kiểm tra xem một ô (ngày, tiết) có hợp lệ với lịch hoạt động của trường hay không.
 * Tự động đồng bộ theo ma trận ca học Thầy/Cô đã tích chọn (Sáng/Chiều từng thứ).
 */
export const isValidSlot = (dayIdx: number, periodIdx: number, customConstraints?: Constraint[]): boolean => {
  if (dayIdx < 0 || dayIdx >= 5 || periodIdx < 0 || periodIdx >= 8) return false;

  const activeShift = getActiveShiftConstraints(customConstraints);
  if (activeShift) {
    const isMorning = periodIdx < 5;
    if (isMorning) {
      if (!activeShift.morningDays.includes(dayIdx)) return false;
      if (periodIdx >= activeShift.morningPeriodCap) return false;
      return true;
    } else {
      if (!activeShift.afternoonDays.includes(dayIdx)) return false;
      if ((periodIdx - 5) >= activeShift.afternoonPeriodCap) return false;
      return true;
    }
  }

  // Mặc định an toàn nếu chưa có cấu hình: Sáng 5 tiết, Chiều 3 tiết từ T2 đến T6
  return true;
};

/**
 * Kiểm tra xem một ô (ngày, tiết) có hợp lệ riêng với một lớp cụ thể hay không.
 */
export const isSlotValidForClass = (
  className: string,
  dayIdx: number,
  periodIdx: number,
  customConstraints?: Constraint[]
): boolean => {
  if (dayIdx < 0 || dayIdx >= 5 || periodIdx < 0 || periodIdx >= 8) return false;

  let list: Constraint[] = customConstraints || [];
  if (!list || list.length === 0) {
    if (typeof localStorage !== 'undefined') {
      try {
        const saved = localStorage.getItem('scheduler_constraints');
        if (saved) list = JSON.parse(saved);
      } catch (e) {
        // ignore
      }
    }
  }

  if (list && list.length > 0) {
    const classRule = list.find(c => c.type === 'CLASS_SHIFT' && c.className === className);
    if (classRule && (classRule.morningDays || classRule.afternoonDays)) {
      const isMorning = periodIdx < 5;
      if (isMorning) {
        if (!classRule.morningDays?.includes(dayIdx)) return false;
        if (periodIdx >= (classRule.morningPeriodCap ?? 5)) return false;
        return true;
      } else {
        if (!classRule.afternoonDays?.includes(dayIdx)) return false;
        if ((periodIdx - 5) >= (classRule.afternoonPeriodCap ?? 3)) return false;
        return true;
      }
    }
  }

  return isValidSlot(dayIdx, periodIdx, list);
};

export const CLASSES = ['6A', '6B', '6C', '7A', '7B', '7C', '8A', '8B', '8C', '9A', '9B'];

// Helper to generate data from the provided list
const generateSampleData = (): InputRow[] => {
  let idCounter = 1;
  const rows: InputRow[] = [];

  const add = (teacher: string, subject: string, className: string, sessions: number) => {
    rows.push({
      id: idCounter++,
      teacher,
      subject,
      className,
      sessionsPerWeek: sessions
    });
  };

  const addMulti = (teacher: string, subject: string, classes: string[], sessions: number) => {
    classes.forEach(c => add(teacher, subject, c, sessions));
  };

  const ALL_CLASSES = CLASSES; // 6A -> 9B

  // --- Data from Image ---
  
  // 1-2. Dương
  add('Dương', 'Công nghệ', '8A', 1);
  add('Dương', 'Công nghệ', '8B', 1);

  // 3. Hà
  add('Hà', 'KHTN-sinh', '7A', 3);

  // 4-8. V. Chung
  add('V. Chung', 'GDTC', '7A', 2);
  add('V. Chung', 'GDTC', '7B', 2);
  add('V. Chung', 'GDTC', '8B', 2);
  add('V. Chung', 'GDTC', '9A', 2);
  add('V. Chung', 'GDTC', '9B', 2);

  // 9-14. Thiệu
  add('Thiệu', 'GDTC', '6A', 2);
  add('Thiệu', 'GDTC', '6B', 2);
  add('Thiệu', 'GDTC', '6C', 2);
  add('Thiệu', 'GDTC', '8B', 2); // Lưu ý: Lớp 8B có 2 giáo viên GDTC (V.Chung & Thiệu) như trong ảnh
  add('Thiệu', 'GDTC', '8C', 2);
  add('Thiệu', 'GDTC', '7C', 2);

  // 15-26. L. Trung
  addMulti('L. Trung', 'Âm nhạc', ALL_CLASSES, 1);
  add('L. Trung', 'Công nghệ', '9B', 1);

  // 27-38. Nguyên
  addMulti('Nguyên', 'Mĩ thuật', ALL_CLASSES, 1);
  add('Nguyên', 'Công nghệ', '7C', 1);

  // 39-45. Phương
  addMulti('Phương', 'T Anh', ['9A', '8A', '8B', '8C', '6A', '6B', '6C'], 3);

  // 46-49. Huế
  addMulti('Huế', 'T Anh', ['7A', '7B', '7C', '9B'], 3);

  // 50-54. Vinh
  addMulti('Vinh', 'KHTN-SINH', ['6B', '6C', '7B', '7C'], 3);
  add('Vinh', 'KHTN-SINH', '8C', 2);

  // 55-59. Sen
  addMulti('Sen', 'KHTN-HÓA', ['9A', '9B', '8A', '8B'], 2);
  add('Sen', 'KHTN-HÓA', '6A', 3);

  // 60-64. Ngơi (Updated from Ngợi)
  addMulti('Ngơi', 'Ngữ văn', ['6B', '6C', '9B'], 4);
  addMulti('Ngơi', 'Sử', ['6B', '6C'], 2);

  // 65-74. Hoan
  addMulti('Hoan', 'Ngữ văn', ['8B', '8C'], 4);
  addMulti('Hoan', 'GDCD', ['6A', '6B', '6C', '8A', '8B', '8C', '7B', '7C'], 1);

  // 75-79. Lan
  addMulti('Lan', 'Ngữ văn', ['8A', '9A'], 4);
  addMulti('Lan', 'GDCD', ['9A', '9B', '7A'], 1);

  // 80-86. Hiếu
  addMulti('Hiếu', 'Ngữ văn', ['6A', '7A'], 4);
  addMulti('Hiếu', 'Sử', ['9A', '9B', '7A', '7B', '7C'], 1);

  // 87-91. Trí
  add('Trí', 'Toán', '8A', 4);
  add('Trí', 'Toán', '7C', 4);
  addMulti('Trí', 'KHTN-LÍ', ['8A', '8B', '8C'], 2);

  // 92-96. Thực
  add('Thực', 'Toán', '6C', 4);
  add('Thực', 'Toán', '9B', 4);
  addMulti('Thực', 'KHTN-LÍ', ['7A', '7B', '7C'], 1);

  // 97-103. Dũng
  add('Dũng', 'Toán', '6A', 4);
  add('Dũng', 'Toán', '8C', 4);
  addMulti('Dũng', 'KHTN-LÍ', ['6A', '6B', '6C'], 1);
  addMulti('Dũng', 'KHTN-LÍ', ['9A', '9B'], 2);

  // 104-115. Đặng
  add('Đặng', 'Toán', '6B', 4);
  addMulti('Đặng', 'Tin', ALL_CLASSES, 1);

  // 116-126. Hoa
  addMulti('Hoa', 'Địa', ALL_CLASSES, 1);

  // 127-128. Thành
  add('Thành', 'Toán', '9A', 4);
  add('Thành', 'Toán', '8B', 4);

  // 129-132. Yến
  addMulti('Yến', 'Sử', ['8A', '8B', '8C', '6A'], 2);

  // 133-135. Đạt
  add('Đạt', 'Toán', '7A', 4);
  add('Đạt', 'Toán', '7B', 4);
  add('Đạt', 'Công nghệ', '8C', 1);

  // 136-143. Thảo
  add('Thảo', 'Ngữ văn', '7B', 4);
  add('Thảo', 'Ngữ văn', '7C', 4);
  addMulti('Thảo', 'Công nghệ', ['6A', '6B', '6C', '7A', '7B', '9A'], 1);

  return rows;
};

export const SAMPLE_DATA: InputRow[] = generateSampleData();